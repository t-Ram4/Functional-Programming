package com.training.functional;
import java.util.function.Supplier;

public class SupplierImpl implements Supplier{

	@Override
	public Object get() {
		
		
		return "India";
	}

}
