package com.training.functional;

import java.util.function.Consumer;
import java.util.function.Predicate;

public class PredicateDemo {
	
	public static void main(String arg[]) {
		
	Predicate <Integer> isAdult = (i) -> {
	      
		 if(i>=18) {
			 
			 return true;
			 
		 }
		 else {
			 
			 return false;
		 }
		
	};
	
	System.out.println("He is an adult: "+isAdult.test(18));
}

}
