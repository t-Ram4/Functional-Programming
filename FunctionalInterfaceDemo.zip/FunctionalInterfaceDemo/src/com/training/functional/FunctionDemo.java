package com.training.functional;

import java.util.function.Function;
import java.util.function.Predicate;

public class FunctionDemo {
	
	public static void main(String arg[]) {
		
		Function <Integer,Integer> multiplier = (n) -> {
		      
			 return n *5;
			
		};
		
		System.out.println("Multiply with n "+multiplier.apply(10));
	}


}
