package com.training.functional;

public class SupplierDemo1 {

	public static void main(String[] args) {
		
		SupplierImpl impl = new SupplierImpl();
		
		System.out.println("Name of our country: "+impl.get());

	}

}
