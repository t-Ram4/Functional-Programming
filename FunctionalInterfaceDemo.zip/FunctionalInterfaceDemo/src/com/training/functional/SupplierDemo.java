package com.training.functional;

import java.util.function.Supplier;

public class SupplierDemo {
	
	public static void main(String arg[]) {
		
		
		Supplier CountryNameSupplier = () -> "India";
		
		System.out.println("Name of our country: "+CountryNameSupplier.get());
		
		
		SupplierImpl impl = new SupplierImpl();
		
		System.out.println("Name of our country: "+impl.get());

	}

}
