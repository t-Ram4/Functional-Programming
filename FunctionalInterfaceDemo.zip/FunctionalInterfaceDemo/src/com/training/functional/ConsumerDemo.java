package com.training.functional;

import java.util.function.Consumer;
import java.util.function.Supplier;

public class ConsumerDemo {
	
public static void main(String arg[]) {
		
		
		Consumer <Integer> OddorEven = (i) -> {
      
			 if(i%2==0) {
				 System.out.println("Even");
				 
			 }
			 else {
				 
				 System.out.println("Odd");
			 }
			
		};
		
		OddorEven.accept(5);
	}

}
